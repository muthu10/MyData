import React from "react";
import { deleteEmployeeAction } from "../Actions/employeeActions";
function DisplayRows(props) {
  const { employee, dispatch } = props;
  return (
    <tr>
      <td>{employee.id}</td>
      <td>{employee.name}</td>
      <td>{employee.email}</td>
      <td>{employee.phone}</td>
      <td>{employee.department}</td>
      <td>
        <button
          type="button"
          className="small-button"
          onClick={() => {
            dispatch(deleteEmployeeAction(employee.id));
          }}
        >
          Delete
        </button>
        <button
          type="button"
          className="small-button"
          onClick={() => {
            props.handlerFromParant(employee);
          }}
        >
          Edit
        </button>
      </td>
    </tr>
  );
}

export default DisplayRows;
