import axios from "axios";
import React from "react";
import addEmployeeAction from "../Actions/employeeActions";
class AddRows extends React.Component {
  constructor(props) {
    super(props);
    this.addEmployee = this.addEmployee.bind(this);
    this.state = {
      departments: [],
      selectedEmployee: props.employeeTobeUpdate
    };
  }

  addEmployee() {
    let submittedValues = {
      name: this.name.value,
      email: this.email.value,
      phone: this.phone.value,
      department: this.dept.value
    };

    this.props.dispatch(addEmployeeAction(submittedValues));
    this.name.value = "";
    this.email.value = "";
    this.phone.value = "";
    this.dept.value = "Delect Department";
  }
  componentDidMount() {
    axios
      .get("http://localhost:3004/departments")
      .then(response => {
        //dispatch({ type: "FETCH_SUCCESS", employees: response.data });
        this.setState({ departments: response.data });
        console.log("Departments: ", response.data);
      })
      .catch(error => {
        console.log("Error ", error);
      });
  }

  render() {
    const depJSX = this.state.departments.map(dep => (
      <option key={dep.id}>{dep.name}</option>
    ));

    let { employeeTobeUpdate } = this.props;

    return (
      <tr>
        <td>
          <input type="text" size="15" />
        </td>
        <td>
          <input
            defaultValue={employeeTobeUpdate[0] ? employeeTobeUpdate.id : ""}
            type="text"
            size="15"
            ref={node => {
              this.name = node;
            }}
          />
        </td>
        <td>
          <input
            type="text"
            size="15"
            ref={node => {
              this.email = node;
            }}
          />
        </td>
        <td>
          <input
            type="text"
            size="15"
            ref={node => {
              this.phone = node;
            }}
          />
        </td>
        <td>
          <select
            ref={node => {
              this.dept = node;
            }}
          >
            <option>Select Department</option>
            {depJSX}
          </select>
        </td>
        <td>
          <button
            type="button"
            className="small-button"
            onClick={this.addEmployee}
          >
            Add
          </button>
        </td>
      </tr>
    );
  }
}
export default AddRows;
