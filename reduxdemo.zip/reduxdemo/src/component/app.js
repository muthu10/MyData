import React from "react";
import { connect } from "react-redux";
import Header from "./Header";
import AddRows from "./AddRows";
import DisplayRows from "./Dispaly";

import { listEmployeeAction } from "../Actions/employeeActions";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { selectedEmployee: [] };
    this.handleData = this.handleData.bind(this);
  }
  handleData(data) {
    this.setState({
      selectedEmployee: data
    });
  }
  componentDidMount() {
    this.props.dispatch(listEmployeeAction());
  }

  render() {
    console.log("Selected Employee", this.state.selectedEmployee);
    const empJSX = this.props.employees.map(element => {
      return (
        <DisplayRows
          key={element.id}
          employee={element}
          dispatch={this.props.dispatch}
          handlerFromParant={this.handleData}
        />
      );
    });
    console.log("empJSX: ", empJSX);
    return (
      <main className="main">
        <Header />

        <section className="content">
          <form action="">
            <div>
              <table id="tab">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Department</th>
                    <th>&nbsp;</th>
                  </tr>
                </thead>

                <tbody>
                  <AddRows
                    dispatch={this.props.dispatch}
                    employeeTobeUpdate={this.state.selectedEmployee}
                  />
                  {/* <DisplayRows /> */}
                  {empJSX}
                </tbody>
              </table>
            </div>
          </form>
        </section>
      </main>
    );
  }
}

function mapStateToProps(state) {
  return {
    employees: state.employees
  };
}
const AppContainer = connect(mapStateToProps)(App);

export default AppContainer;
