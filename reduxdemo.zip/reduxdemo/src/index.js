import React from "react";
import ReactDOM from "react-dom";
import { createStore, applyMiddleware } from "redux";
import { Provider } from "react-redux";
import { composeWithDevTools } from "redux-devtools-extension";
import logger from "redux-logger";
import thunk from "redux-thunk";

import "./styles.css";
import EmployeeReducer from "./Reducers/employeeReducers";
import AppContainer from "./component/app";

const spaStore = createStore(
  EmployeeReducer,
  composeWithDevTools(applyMiddleware(thunk, logger))
);

ReactDOM.render(
  <Provider store={spaStore}>
    <AppContainer />
  </Provider>,
  document.getElementById("root")
);
