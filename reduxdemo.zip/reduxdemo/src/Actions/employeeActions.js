import axios from "axios";

export function listEmployeeAction() {
  return function(dispatch) {
    console.log("action-creator");
    dispatch({
      type: "FETCHING"
    });

    axios
      .get("http://localhost:3004/employees")
      .then(response => {
        dispatch({ type: "FETCH_SUCCESS", employees: response.data });
        console.log(response.data);
      })
      .catch(error => {
        dispatch({ type: "FETCH_ERROR", error: error.message });
      });
  };
}

export default function addEmployeeAction(emp) {
  return function(dispatch) {
    axios
      .post("http://localhost:3004/employees", emp)
      .then(response => {
        dispatch(listEmployeeAction());
        console.log(response.data);
      })
      .catch(error => {
        //dispatch({ type: "FETCH_ERROR", error: error.message });
        console.log("Error: ", error);
      });
  };
}

export function deleteEmployeeAction(id) {
  return function(dispatch) {
    axios
      .delete(`http://localhost:3004/employees/${id}`)
      .then(response => {
        dispatch(listEmployeeAction());
        console.log(response.data);
      })
      .catch(error => {
        //dispatch({ type: "FETCH_ERROR", error: error.message });
        console.log("Error: ", error);
      });
  };
}

export function updateEmployeeAction(emp) {
  return function(dispatch) {
    axios
      .put("http://localhost:3004/employees", emp)
      .then(response => {
        dispatch(listEmployeeAction());
        console.log(response.data);
      })
      .catch(error => {
        //dispatch({ type: "FETCH_ERROR", error: error.message });
        console.log("Error: ", error);
      });
  };
}
